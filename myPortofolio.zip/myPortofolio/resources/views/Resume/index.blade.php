@extends('layouts.main')

@section('container')
<div class="mt-5 d-flex justify-content-center">
  <div class="row">
    <div class="col-lg-8 col-8">
      <h1 class="font-bebas">I'm Ade Irmayanti</h1>
      
    </div>

    <div class="col-lg-4 col-4">
      my image
    </div>
  </div>
</div>
@endsection