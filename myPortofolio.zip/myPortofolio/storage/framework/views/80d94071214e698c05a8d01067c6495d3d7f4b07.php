

<?php $__env->startSection('container'); ?>
<div class="mt-5 d-flex justify-content-center">
  <div class="row">
    <div class="col-lg-8 col-8">
      <h1 class="font-bebas">I'm Ade Irmayanti</h1>
      
    </div>

    <div class="col-lg-4 col-4">
      my image
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel-project\myPortofolio\resources\views/Resume/index.blade.php ENDPATH**/ ?>